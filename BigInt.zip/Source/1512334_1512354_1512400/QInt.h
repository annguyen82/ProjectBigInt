﻿#pragma once
#include <string>
#include <math.h>
#include <fstream>
#include <iostream>
using namespace std;

class QInt
{
private:
	int A[4];
public:
	QInt();
	~QInt();

	//Chia chuỗi cho 2
	string StrDiv2(string X);			

	//Bật bit 1
	void TurnOnBit(int &x, int j);		

	//Tắt bit
	void TurnOffBit(int &x, int j);		

	//Đưa bit vào QInt
	void SetBit(int bit, int i);		

	//Cộng QInt với 1
	void SumWith1();					

	//Lấy bit thứ i
	int GetBitI(int x, int j);

	//Chuan hoa do dai 2 xau
	void Standard(string &a, string &b);		

	//Cộng chuỗi
	string Sum(string a, string b);				

	//Trừ chuỗi
	string Sub(string a, string b);				

	//Nhân ký tự với chuỗi
	string Multiply(char a, string b);

	//Chuyển sang nhị phân đưa vào QInt
	void StrToQInt(string X);		

	//Kiểm tra số âm
	bool IsNagativeInt();

	//In ra số QInt
	string PrintQInt();		

	//Hàm in ra số dưới dạng nhị phân
	string PrintBinary();

	//Chuyển từ dãy nhị phân sang thập lục phân
	string BinToHex(string);		

	//Chuyển từ dãy thập lục phân sang nhị phân
	string HexToBin(string); 

	//Chuyển từ dãy nhị phân sang thập phân
	string BinToDec(string);	

	//Toán tử gán bằng
	QInt& operator=(const QInt&); 
	
	//Toán tử cộng QInt
	QInt operator+(const QInt&); 

	//Toán tử trừ QInt
	QInt operator-(const QInt&);	

	//Toán tử nhân QInt
	QInt operator*(const QInt&);		

	//Toán tử chia QInt
	QInt operator/(const QInt&);	
	
	//Toán tử AND
	QInt operator&(const QInt&);	

	//Toán tử OR
	QInt operator|(const QInt&);	

	//Toán tử XOR
	QInt operator^(const QInt&);	

	//Toán tử NOT
	QInt& operator~();		

	//Dịch phải 1 bit
	void Trans1Bit_R();

	//Dịch trái 1 bit
	void Trans1Bit_L();

	//Dịch phải k bit
	QInt& operator>>(int);

	//Dịch trái k bit
	QInt& operator<<(int);	

	//Phép xoay trái
	QInt& rol();	

	//Phép xoay phải
	QInt& ror();
};