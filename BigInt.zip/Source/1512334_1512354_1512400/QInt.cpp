﻿#include "QInt.h"

QInt::QInt()
{
	A[0] = 0, A[1] = 0, A[2] = 0, A[3] = 0; //Khởi tạo giá trị 0 cho tất cả các bit
}

QInt::~QInt()
{
}

string QInt::StrDiv2(string X)
{	
	string a = "";
	int cdai = X.length();			//Lấy giá trị độ dài của chuỗi

	int du = X[0] - 48;				//Biến du lưu trữ giá trị của X[0]

	string x;

	for (int i = 0; i < cdai; i++)		//Thực hiện chia
	{
		x = (du / 2) + 48;			//du chia 2 lấy phần nguyên => ký tự
		a = a + x;
		du = (du % 2) * 10 + (X[i + 1] - 48);		//Cập nhật lại du

	}
	if (a.length()>1 && a[0] == '0') a.erase(0, 1);			//Xóa ký tự 0 đầu chuỗi
	return a;
}

void QInt::TurnOnBit(int &x, int j)		//Bật bit 1
{
	int temp = 1;
	temp = temp << j;
	x = temp | x;
}
void QInt::TurnOffBit(int &x, int j)	//Tắt bit 
{
	int temp = 1;
	temp = temp << j;
	x = ~(temp)&x;
}
void QInt::SetBit(int bit, int i)		//Đưa bit vào
{
	i = 127 - i;
	int x, j;
	if (i >= 0 && i <= 31)			//Xác định vị trí của i trên phần tử nào của biến QInt
	{
		j = i;
		if (bit == 1)
		{
			TurnOnBit(this->A[3], j);
		}
	}
	else if (i >= 32 && i <= 63)
	{
		j = i - 32;
		if (bit == 1)
		{
			TurnOnBit(this->A[2], j);
		}
	}
	else if (i >= 64 && i <= 95)
	{
		j = i - 64;
		if (bit == 1)
		{
			TurnOnBit(this->A[1], j);
		}
	}
	else
	{
		j = i - 96;
		if (bit == 1)
		{
			TurnOnBit(this->A[0], j);
		}
	}
}
//Trả về giá trị của bit thứ j
int QInt::GetBitI(int x, int j) 
{
	x = (x >> j) & 1;
	return x;
}
void QInt::SumWith1()
{
	for (int i = 3; i >= 0; i--)
	{
		for (int j = 0; j < 32; j++)
		{
			if (GetBitI(this->A[i], j) == 1)
			{
				TurnOffBit(this->A[i], j);
			}
			else
			{
				TurnOnBit(this->A[i], j);
				return;
			}
		}
	}
}

void QInt::StrToQInt(string X)		//Chuyển xâu nhập vào thành nhị phân
{
	int temp = 0;
	if (X[0] == '-')				
	{
		temp = 1;
		X.erase(0, 1);				//Cắt dấu '-' ra khỏi chuỗi
	}
	int i = 127;
	while (X != "0")
	{
		int bit = (X[X.length() - 1] - 48) % 2;
		this->SetBit(bit, i);
		X = StrDiv2(X);
		i--;
	}
	if (temp==1)				//Nếu là số âm thì chuyển sang bù 2
	{
		~*this;
		SumWith1();
	}
}

void QInt::Standard(string &a, string &b)					// lam 2 xau co do dai bang nhau
{
	int len1 = a.length();
	int len2 = b.length();
	if (len1 >= len2)
	{
		b.insert(0, len1 - len2, '0');    // chen vao dau cua b cac ky tu '0'
	}
	else
	{
		a.insert(0, len2 - len1, '0');    // chen vao dau cua a cac ky tu '0'
	}
}

string QInt::Sum(string a, string b)			// tong 2 so
{
	string s = "";
	Standard(a, b);					   // chuan hoa
	int l = a.length();

	int temp = 0;
	for (int i = l - 1; i >= 0; i--)   // duyet va cong
	{
		temp = (a[i] - 48) + (b[i] - 48) + temp;    // tinh tong tung doi mot
		s.insert(0, 1, (temp % 10) + 48);         // gan phan don vi vao
		temp = temp / 10;     // lay lai phan hang chuc
	}
	if (temp>0)  // neu hang chuc > 0 thi them vao KQ
	{
		s.insert(0, 1, temp + 48);
	}
	return s;
}

string QInt::Sub(string a, string b)
{
	string s = "";
	Standard(a, b);					   // Chuẩn hóa
	int l = a.length();

	int temp = 0;
	for (int i = l - 1; i >= 0; i--)   // duyet va cong
	{
		if ((a[i] - 48) >= ((b[i] - 48) + temp))
		{
			temp = (a[i] - 48) - (b[i] - 48) - temp;
			s.insert(0, 1, temp + 48);
			temp = 0;
		}
		else
		{
			temp = (a[i] - 48) + 10 - (b[i] - 48) - temp;
			s.insert(0, 1, temp + 48);
			temp = 1;
		}
	}
	while (s[0] == '0')
	{
		s.erase(0, 1);
	}
	return s;
}

//Nhân chuỗi với ký tự 1 số
string QInt::Multiply(char a, string b)
{
	string s = "";
	int temp = 0;
	for (int i = b.length() - 1; i >= 0; i--)
	{
		temp = (a - 48) * (b[i] - 48) + temp;
		s.insert(0, 1, (temp % 10) + 48);
		temp = temp / 10;
	}

	if (temp>0)
	{
		s.insert(0, 1, temp + 48);
	}
	return s;
}

//Kiem tra có phải số âm
bool QInt::IsNagativeInt()
{
	if (GetBitI(this->A[0], 31) == 1)
		return true;
	return false;
}

//In số QInt ở dạng thập phân
string QInt::PrintQInt()				
{
	int dem = 127;
	string s = "";
	for (int i = 0; i < 4; i++)
	{
		for (int j = 31; j >= 0; j--)
		{
			if (GetBitI(this->A[i], j) == 1)
			{
				string temp = "1";
				for (int k = 1; k <= dem; k++)
				{
					temp = Multiply('2', temp);
				}
				s = Sum(s, temp);
			}
			dem--;
		}
	}
	if (IsNagativeInt())
	{
		string temp = "1";
		for (int k = 1; k <= 127; k++)
		{
			temp = Multiply('2', temp);
		}
		s = Sub(s, temp);
		s = Sub(temp, s);
		s.insert(0, 1, '-');
	}
	if (s == "") s.insert(0, 1, '0');
	return s;
}

//In số QInt ở dạng nhị phân
string QInt::PrintBinary()
{
	string result = "";
	for (int i = 0; i < 4; i++)
	{
		for (int j = 31; j >= 0; j--)
		{
			result+=GetBitI(A[i], j)+48;
		}
	}
	while (result[0] == '0'&&result.length()!=1) result.erase(0, 1);
	return result;
}

//Chuyển số QInt từ nhị phân sang thập lục phân
string QInt::BinToHex(string b)
{
	string t;
	for (int i = 0; i < 128; i++)
	{
		t += "0";
	}
	Standard(b, t);
	char hex[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
	string result = "";
	string temp = "";
	for (int j = b.length()-1;j>=0;)
	{
		// Tạo xâu chứa dãy nhị phân 4 bit
		while (temp.length() != 4)
		{
			temp.insert(0, 1, b[j]);
			j--;
		}
		// Chuyển dãy nhị phân 4 bit sang dạng thập phân
		if (temp.length() == 4)
		{
			int result_1 = 0;
			for (int k = 0; k < 4; k++)
			{
				if (temp[temp.length() - k - 1] == '1')
				{
					result_1 += pow(2, k);
				}
			}
			result.insert(0, 1, hex[result_1]);
			temp = "";
		}
	}
	while (result[0] == '0'&&result.length() != 1) result.erase(0, 1);
	
	return result;
}

//Chuyển từ thập lục phân sang nhị phân
string QInt::HexToBin(string h)
{
	string result = "";
	string bin[] = { "0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010"
		, "1011", "1100", "1101", "1110", "1111" };
	for (int i = 0; i < h.length(); i++)
	{
		switch (h[i])
		{
		case '0': case '1': case '2':case '3':case '4':case '5':case '6':case '7':case '8':case '9':
			result += bin[h[i]-48]; break;
		case 'A': result += bin[10]; break;
		case 'B': result += bin[11]; break;
		case 'C': result += bin[12]; break;
		case 'D': result += bin[13]; break;
		case 'E': result += bin[14]; break;
		case 'F': result += bin[15]; break;
		}
	}

	return result;
}

//Chuyển từ hệ nhị phân sang thập phân
string QInt::BinToDec(string b)
{
	int dem = b.length()-1;
	string result = "";
	for (int i = 0; i < b.length(); i++)
	{
		if (b[i] == '1')
		{
			string temp = "1";
			for (int k = 1; k <= dem; k++)
			{
				temp = Multiply('2', temp);
			}
			result = Sum(result, temp);
		}
		dem--;
	}
	if (b.length()==128&&b[0]=='1')
	{
		string temp = "1";
		for (int k = 1; k <= 127; k++)
		{
			temp = Multiply('2', temp);
		}
		result = Sub(result, temp);
		result = Sub(temp, result);
		result.insert(0, 1, '-');
	}
	return result;
}
// Toan tu cong
QInt QInt::operator+(const QInt& M)
{
	QInt Q = M;
	QInt result;
	int memory = 0; int dem = 127;
	for (int i = 3; i >= 0; i--) {
		for (int j = 0; j <32; j++) {
			int kq = this->GetBitI(this->A[i], j) + Q.GetBitI(Q.A[i], j);
			switch (kq) {
			case 0:
				if (memory == 0) {
					result.SetBit(0, dem);
					dem--;
					break;
				}
				else if (memory == 1) {
					result.SetBit(1, dem);
					dem--;
					memory = 0;
					break;
				}
			case 1:
				if (memory == 0) {
					result.SetBit(1, dem);
					dem--;
					break;
				}
				else if (memory == 1) {
					result.SetBit(0, dem);
					dem--;
					break;
				}
			case 2:
				if (memory == 0) {
					result.SetBit(0, dem);
					memory = 1;
					dem--;
					break;
				}
				else if (memory == 1) {
					result.SetBit(1, dem);
					dem--;
					break;

				}
			}
		}
	}
	return result;
}

// Toan tu tru
QInt QInt::operator-(const QInt &M)
{
	QInt Q = M;
	QInt result;
	~Q;
	Q.SumWith1();
	result = *this + Q;
	return result;
}

//Toán tử nhân
QInt QInt::operator*(const QInt &Qt)
{
	QInt Q = Qt;
	QInt M = (*this);
	int Q_1 = 0;
	QInt A;
	int k = 128;
	while (k > 0)
	{
		int Q0 = GetBitI(Q.A[3], 0);				//Lấy bít nhỏ nhất của Q
		if (Q0 == 1 && Q_1 == 0)
		{
			A = A - M;
		}
		else if (Q0 == 0 && Q_1 == 1)
		{
			A = A + M;
		}
		Q_1 = Q0;
		Q >> 1;
		int bit0A = GetBitI(A.A[3], 0);					//Lấy bit nhỏ nhất của A			
		if (bit0A == 1)									//Nếu bit cuối của A là 1
			TurnOnBit(Q.A[0], 31);						//Bật bit đầu của Q thành 1
		else TurnOffBit(Q.A[0], 31);
		A >> 1;
		k--;
	}
	return Q;
}

//Toán tử chia
QInt QInt::operator/(const QInt &Q)
{
	QInt A;
	QInt M = Q;
	QInt result = *this;
	if (M.PrintQInt() == "0")
	{
		return M;
	}
	int k = 128;
	int d1 = GetBitI(result.A[0], 31);		//Lấy bit dấu của result
	int d2 = GetBitI(M.A[0], 31);			//Lấy bit dấu của M
	if (d1 == 1)							//Nếu result là số âm thì chuyển sang bù 2
	{
		~result;
		result.SumWith1();
	}	
	if (d2 == 1)							//Nếu M là số âm thì chuyển sang bù 2
	{
		~M;
		M.SumWith1();
	}
	while (k > 0)
	{
		int temp = GetBitI(result.A[0], 31);
		result << 1;
		A << 1;
		if (temp == 1) TurnOnBit(A.A[3], 0);
		else TurnOffBit(A.A[3], 0);
		A = A - M;
		if (GetBitI(A.A[0], 31) == 1)
		{
			TurnOffBit(result.A[3], 0);
			A = A + M;
		}	
		else TurnOnBit(result.A[3], 0);
		k--;
	}
	if (d1 != d2)
	{
		~result;
		result.SumWith1();
	}
	//cout << "\nSo du: " << A.PrintBinary();
	//cout << "\nThuong: " << result.PrintBinary() << endl;
	return result;
}

//Toán tử gán bằng
QInt& QInt::operator=(const QInt& Q)
{
	if (this != &Q)
	{
		for (int i = 0; i < 4; i++)
		{
			A[i] = Q.A[i];
		}
	}
	return *this;
}

//Toán tử AND
QInt QInt::operator&(const QInt& Q)
{
	QInt temp;
	for (int i = 0; i < 4; i++)
	{
		temp.A[i] = A[i] & Q.A[i];
	}
	return temp;
}

//Toán tử OR
QInt QInt::operator|(const QInt& Q)
{
	QInt temp;
	for (int i = 0; i < 4; i++)
	{
		temp.A[i] = A[i] | Q.A[i];
	}
	return temp;
}

//Toán tử XOR
QInt QInt::operator^(const QInt& Q)
{
	QInt temp;
	for (int i = 0; i < 4; i++)
	{
		temp.A[i] = A[i] ^ Q.A[i];
	}
	return temp;
}

//Toán tử NOT
QInt& QInt::operator~()
{
	int temp = 1;
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 32; j++)
		{
			temp = temp << j;
			A[i] = A[i] ^ temp;
			temp = 1;
		}
	}
	return *this;
}

//Dịch phải 1 bit
void QInt::Trans1Bit_R()
{
	A[3] = A[3] >> 1;					//Dịch sang phải 1 bit của 32 bit nhỏ nhất

	for (int i = 2; i >= 0; i--)
	{
		int temp = GetBitI(A[i], 0);		//Lấy giá trị bit thứ 0 của phần A[i]

		if (temp == 1)
		{
			TurnOnBit(A[i + 1], 31);			//Bật bit thứ ...... của A[i+1]
		}
		else TurnOffBit(A[i + 1], 31);			//Tăt bit thứ ...... của A[i+1]

		A[i] = A[i] >> 1;						// Dịch sang phải 1 bit của 32 bit phần hiện tại
	}
}

//Dịch trái 1 bit
void QInt::Trans1Bit_L()
{
	A[0] = A[0] << 1;					//Dịch sang trái 1 bit của 32 bit nhỏ nhất

	for (int i = 1; i <= 3; i++)
	{
		int temp = GetBitI(A[i], 31);		//Lấy giá trị bit thứ 31 của phần A[i]

		if (temp == 1)
		{
			TurnOnBit(A[i - 1], 0);			//Bật bit thứ ...... của A[i-1]
		}
		else TurnOffBit(A[i - 1], 0);			//Tăt bit thứ ...... của A[i-1]

		A[i] = A[i] << 1;						// Dịch sang phải k bit của 32 bit phần hiện tại
	}
}

//Dịch phải k bit
QInt& QInt::operator>>(int k)
{
	for (int i = 0; i < k; i++)
	{
		this->Trans1Bit_R();
	}

	return *this;
}

//Dịch trái k bit
QInt& QInt::operator<<(int k)
{
	for (int i = 0; i < k; i++)
	{
		this->Trans1Bit_L();
	}

	return *this;
}

//Phép xoay trái
QInt& QInt::rol()
{
	int temp = GetBitI(A[0],31);
	*this << 1;
	if (temp == 1) TurnOnBit(A[3], 0);
	else TurnOffBit(A[3], 0);
	return *this;
}

//Phép xoay phải
QInt& QInt::ror()
{
	int temp = GetBitI(A[3], 0);
	*this >> 1;
	if (temp == 1) TurnOnBit(A[0], 31);
	else TurnOffBit(A[0], 31);
	return *this;
}