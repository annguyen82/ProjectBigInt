﻿#include <iostream>
using namespace std;

//Đọc và ghi file
void Read_Write_File(char *filename1, char* filename2); 

// Kiểm tra chế độ 1 chỉ thị hay 2
int Check_Mode(string s);

//Xử lý chế độ 1 chỉ thị
string ProcessedMode1(string s); 

//Xử lý chế độ 1 chỉ thị với nhị phân
string Mode1_With_2(string arr[]);

//Xử lý chế độ 1 chỉ thị với thập phân
string Mode1_With_10(string arr[]); 

//Xử lý chế độ 1 chỉ thị với thập lục phân
string Mode1_With_16(string arr[]); 

//Xử lý chế độ 2 chỉ thị
string ProcessedMode2(string s); 