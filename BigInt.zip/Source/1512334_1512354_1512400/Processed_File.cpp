﻿#include "Processed_File.h"
#include "QInt.h"

//Đọc và ghi file
void Read_Write_File(char *filename1, char* filename2)
{
	fstream f1, f2;
	f1.open(filename1, ios::in);
	if (f1.fail())
	{
		cout << "Failed to open this file!" << endl;
		return;
	}
	f2.open(filename2, ios::out);
	string line;
	while (!f1.eof()) //Kiểm tra có đọc đến cuối file
	{
		getline(f1, line);
		if (Check_Mode(line))
		{
			string result = ProcessedMode1(line);
			f2 << result << endl;
		}
		else
		{
			string result = ProcessedMode2(line);
			f2 << result << endl;
		}
	}
	cout << "--------SUCCCES------" << endl;
	fcloseall();
}

// Kiểm tra chế độ 1 chỉ thị hay 2
int Check_Mode(string s)
{
	string temp;
	for (int i = s.length() - 1; i >= 0; i--)
	{
		if (s[i] == ' ')
		{
			while (s[i - 1] != ' ')
			{
				temp = +s[i - 1];
				i--;
			}
			break;
		}
	}

	if (temp[0]<'0' || temp[0]>'9') return 1; // Chế độ 1 chỉ thị
	return 0; //Chế độ 2 chỉ thị
}

//Xử lý chế độ 1 chỉ thị
string ProcessedMode1(string s)
{
	int count = 0;

	for (int i = 0; i < s.length(); i++)
	{
		if (s[i] == ' ') count++;
	}
	if (count == 3)
	{
		string arr[] = { "", "", "", "" };
		int j = 0;								//phần tử thứ j của mảng
		for (int i = 0; i < s.length(); i++)			//Tách các thành phần dữ liệu
		{
			arr[j] += s[i];
			if (s[i + 1] == ' ')
			{
				i++;
				j++;
			}
		}

		//Xu ly
		if (arr[0] == "2")
		{
			return Mode1_With_2(arr);
		}
		else if (arr[0] == "10")
		{
			return Mode1_With_10(arr);
		}
		else if (arr[0] == "16")
		{
			return Mode1_With_16(arr);
		}
		else return "Chuong trinh khong thuc hien duoc";
	}
	else if (count == 2)
	{
		string arr[] = { "", "", "" };
		int j = 0;					//phần tử thứ j của mảng
		for (int i = 0; i < s.length(); i++)				//Tách các thành phần dữ liệu
		{
			arr[j] += s[i];
			if (s[i + 1] == ' ')
			{
				i++;
				j++;
			}
		}

		//Xử lý
		if (arr[0] == "2")
		{
			QInt a;
			a.StrToQInt(a.BinToDec(arr[2]));  
			if (arr[1] == "ror")
			{
				a.ror();
			}
			else if (arr[1] == "rol")
			{
				a.rol();
			}
			else if (arr[1] == "~")
			{
				~a;
			}
			return a.PrintBinary();
		}
		else if (arr[0] == "10")
		{
			QInt a;
			a.StrToQInt(arr[2]);
			if (arr[1] == "ror")
			{
				a.ror();
			}
			else if (arr[1] == "rol")
			{
				a.rol();
			}
			else if (arr[1] == "~")
			{
				~a;
			}
			return a.PrintQInt();

		}
		else if (arr[0] == "16")
		{
			QInt a;
			a.StrToQInt(a.BinToDec(a.HexToBin(arr[2])));
			if (arr[1] == "ror")
			{
				a.ror();
			}
			else if (arr[1] == "rol")
			{
				a.rol();
			}
			else if (arr[1] == "~")
			{
				~a;
			}
			return a.BinToHex(a.PrintBinary());
		}
	}
}

//Xử lý chế độ 1 chỉ thị với nhị phân
string Mode1_With_2(string arr[])
{
	QInt a, b;
	a.StrToQInt(a.BinToDec(arr[1]));

	if (arr[2] == "+")
	{
		b.StrToQInt(b.BinToDec(arr[3]));
		a = a + b;
	}
	else if (arr[2] == "-")
	{
		b.StrToQInt(b.BinToDec(arr[3]));
		a = a - b;
	}
	else if (arr[2] == "*")
	{
		b.StrToQInt(b.BinToDec(arr[3]));
		a = a * b;
	}
	else if (arr[2] == "/")
	{
		while (arr[3][0] == '0'&&arr[3].length() != 1) arr[3].erase(0, 1);
		if (arr[3] == "0") return "ERROR";
		b.StrToQInt(b.BinToDec(arr[3]));
		
		a = a / b;
	}
	else if (arr[2] == "&")
	{
		b.StrToQInt(b.BinToDec(arr[3]));
		a = a & b;
	}
	else if (arr[2] == "^")
	{
		b.StrToQInt(b.BinToDec(arr[3]));
		a = a ^ b;
	}
	else if (arr[2] == "|")
	{
		b.StrToQInt(b.BinToDec(arr[3]));
		a = a | b;
	}
	else if (arr[2] == ">>")
	{
		int x = atoi(arr[3].c_str());
		a >> x;
	}
	else if (arr[2] == "<<")
	{
		int x = atoi(arr[3].c_str());
		a << x;
	}
	return a.PrintBinary();
}

//Xử lý chế độ 1 chỉ thị với thập phân
string Mode1_With_10(string arr[])
{
	QInt a, b;
	a.StrToQInt(arr[1]);
	b.StrToQInt(arr[3]);
	if (arr[2] == "+") a = a + b;
	else if (arr[2] == "-") a = a - b;
	else if (arr[2] == "*")	a = a * b;
	else if (arr[2] == "/")
	{
		if (b.PrintQInt() == "0") return "ERROR";
		a = a / b;
	}
	else if (arr[2] == "&") a = a & b;
	else if (arr[2] == "^") a = a ^ b;
	else if (arr[2] == "|") a = a | b;
	else if (arr[2] == ">>")
	{
		int x = atoi(arr[3].c_str());
		a >> x;
	}
	else if (arr[2] == "<<")
	{
		int x = atoi(arr[3].c_str());
		a << x;
	}
	return a.PrintQInt();
}

//Xử lý chế độ 1 chỉ thị với thập lục phân
string Mode1_With_16(string arr[])
{
	QInt a, b;
	a.StrToQInt(a.BinToDec(a.HexToBin(arr[1])));

	if (arr[2] == "+")
	{
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		a = a + b;
	}
	else if (arr[2] == "-")
	{
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		a = a - b;
	}
	else if (arr[2] == "*")
	{
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		a = a * b;
	}
	else if (arr[2] == "/")
	{
		while (arr[3][0] == '0'&&arr[3].length() != 1) arr[3].erase(0, 1);
		if (arr[3] == "0") return "ERROR";
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		
		a = a / b;
	}
	else if (arr[2] == "&")
	{
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		a = a & b;
	}
	else if (arr[2] == "^")
	{
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		a = a ^ b;
	}
	else if (arr[2] == "|")
	{
		b.StrToQInt(b.BinToDec(b.HexToBin(arr[3])));
		a = a | b;
	}
	else if (arr[2] == ">>")
	{
		int x = atoi(arr[3].c_str());
		a >> x;
	}
	else if (arr[2] == "<<")
	{
		int x = atoi(arr[3].c_str());
		a << x;
	}
	return a.BinToHex(a.PrintBinary());
}

//Xử lý chế độ 2 chỉ thị
string ProcessedMode2(string s)
{
	string arr[3] = { "", "", "" };
	int j = 0;			//phần tử thứ j của mảng
	for (int i = 0; i < s.length(); i++)				//Tách các thành phần dữ liệu
	{
		arr[j] += s[i];
		if (s[i + 1] == ' ')
		{
			i++;
			j++;
		}
	}
	if (arr[0] == "2")
	{
		if (arr[1] == "10")
		{
			QInt a;
			return a.BinToDec(arr[2]);
		}
		else if (arr[1] == "16")
		{
			QInt a;
			return a.BinToHex(arr[2]);
		}
	}
	else if (arr[0] == "10")
	{
		if (arr[1] == "2")
		{
			QInt a;
			a.StrToQInt(arr[2]);
			return a.PrintBinary();
		}
		else  if (arr[1] == "16")
		{
			QInt a;
			a.StrToQInt(arr[2]);
			return a.BinToHex(a.PrintBinary());
		}
	}
	else if (arr[0] == "16")
	{
		if (arr[1] == "2")
		{
			QInt a;
			return a.HexToBin(arr[2]);
		}
		else  if (arr[1] == "10")
		{
			QInt a;
			return a.BinToDec(a.HexToBin(arr[2]));
		}
	}
}