﻿#include "QInt.h"
#include "Processed_File.h"

//Cài đăt hàm main ở dạng tham số dòng lệnh
int main(int argc, char* argv[])
{
	if (argc == 3)
	{
		Read_Write_File(argv[1], argv[2]);
	}
	system("pause");
	return 0;

}